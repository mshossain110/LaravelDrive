<div class="panel details-container cf">
  <?php $tpl->render($panel_details) ?>
</div>